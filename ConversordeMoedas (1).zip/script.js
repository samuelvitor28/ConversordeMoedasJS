function converter() {
    var primeiramoeda = document.getElementById("primeiramoeda").value;
    var val1 = parseFloat(document.getElementById("valor").value);
    var conversao = document.getElementById("segundamoeda").value;

    var res = document.getElementById("resultado");

if (primeiramoeda === "real" && conversao === "dolar") {
        resultado = val1 / 5;
    } else if (primeiramoeda === "real" && conversao === "euro") {
        resultado = val1 / 6; 
    } else if (primeiramoeda === "real" && conversao === "libra") {
        resultado = val1 / 7; 
    } else if (primeiramoeda === "real" && conversao === "iene") {
        resultado = val1 * 20; 
    } else if (primeiramoeda === "dolar" && conversao === "real") {
        resultado = val1 * 5; 
    } else if (primeiramoeda === "dolar" && conversao === "euro") {
        resultado = val1 / 1.18; 
    } else if (primeiramoeda === "dolar" && conversao === "libra") {
        resultado = val1 / 1.39; 
    } else if (primeiramoeda === "dolar" && conversao === "iene") {
        resultado = val1 * 110; 
    } else if (primeiramoeda === "euro" && conversao === "real") {
        resultado = val1 * 6; 
    } else if (primeiramoeda === "euro" && conversao === "dolar") {
        resultado = val1 * 1.18; 
    } else if (primeiramoeda === "euro" && conversao === "libra") {
        resultado = val1 / 1.19; 
    } else if (primeiramoeda === "euro" && conversao === "iene") {
        resultado = val1 * 130;
    } else if (primeiramoeda === "libra" && conversao === "real") {
        resultado = val1 * 7;
    } else if (primeiramoeda === "libra" && conversao === "dolar") {
        resultado = val1 * 1.39;
    } else if (primeiramoeda === "libra" && conversao === "euro") {
        resultado = val1 * 1.19;
    } else if (primeiramoeda === "libra" && conversao === "iene") {
        resultado = val1 * 155; 
    } else if (primeiramoeda === "iene" && conversao === "real") {
        resultado = val1 / 20;
    } else if (primeiramoeda === "iene" && conversao === "dolar") {
        resultado = val1 / 110; 
    } else if (primeiramoeda === "iene" && conversao === "euro") {
        resultado = val1 / 130; 
    } else if (primeiramoeda === "iene" && conversao === "libra") {
        resultado = val1 / 155; 
    }

    res.innerHTML = resultado.toFixed(2); 
}
    
